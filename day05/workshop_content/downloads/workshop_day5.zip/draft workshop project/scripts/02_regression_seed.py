# %% [markdown]
# # Round 2 - CYP inhibition on the OpenADMET challenge set
#
# ## The data
#
# The challenge train/test split, pulled from HuggingFace
# (`openadmet/cyp-challenge-train-test`). Four isoforms, each with a pIC50 for direct
# inhibition in the column `<TARGET>_pIC50_direct_inhibition`. Not every molecule is
# measured against every isoform, so each target needs its own row mask - this is not
# one table with four clean columns.
#
# Each test molecule also carries `..._conf_low` and `..._conf_high`: the credible
# interval of the measurement.
#
# Use the split as it ships. Do NOT reshuffle: the test molecules were chosen to sit
# prospectively ahead of the training set.
# Keep it this way, and your final scores are comparable to the leaderboard.

# %%
from __future__ import annotations

from pathlib import Path

from datasets import load_dataset

HERE = Path(__file__).resolve().parent if "__file__" in globals() else Path.cwd()
ROOT = HERE.parent if HERE.name == "scripts" else HERE

DATASET = "openadmet/cyp-challenge-train-test"
TARGETS = ["CYP1A2", "CYP2C9", "CYP2D6", "CYP3A4"]
SEED = 0

HF_CACHE = ROOT / "data" / "huggingface"
MODELS = ROOT / "models"
OUT = ROOT / "results_cyp"
OUT.mkdir(exist_ok=True)


def col(target: str) -> str:
    return f"{target}_pIC50_direct_inhibition"


# %%
ds = load_dataset(DATASET, cache_dir=str(HF_CACHE))
frames = {split: ds[split].to_pandas() for split in ("train", "test")}
for split, df in frames.items():
    print(f"{split:5s} {len(df)} molecules")

print(frames["train"].columns.tolist())


# %% [markdown]
# ## TASK 1 - Features
#
# The same two blocks as round 1:
# Use the same descriptor list in the same order, and the 2048-bit ECFP4.
#
# One difference from round 1: you do not need to standardize. These are curated measured
# compounds and the organisers' SMILES are what the reported pIC50 refers to.
#
# Check for unparseable SMILES, and save the measures to a .npz file.

# %%


# %% [markdown]
# ## TASK 2 - Look at the split before you model it
#
# Two questions:
#
# *Leakage*: for each test molecule, the highest Tanimoto to any training molecule
# same calculation as round 1. Exact SMILES shared between the splits?
#
# *Distribution shift*: per isoform, how many molecules are labelled, and how do the
# train and test pIC50 distributions compare (mean, spread)?
# One isoform is measuring noticeably different chemistry in the two halves.
# A model can be perfectly sound and still score badly when that gap is large.
#
# Plot it: the similarity histogram, and a panel per isoform on common bins.

# %%


# %% [markdown]
# ## TASK 3 - One regressor per isoform
#
# A `RandomForestRegressor` per isoform on descriptors and fingerprints concatenated.
# Mask out molecules with no measurement for that isoform.
# 
# Hold the forest parameters constant across isoforms so the comparison between them is like-for-like.
#
# Print one shallow `DecisionTreeRegressor` (pick the best-populated isoform)
# and read its splits: the leaf values are predicted pIC50.
#
# Then: how much importance sits in the 15 descriptors versus the 2048 bits, and which
# single descriptor matters most per isoform?

# %%


# %% [markdown]
# ## TASK 4 - Evaluation metric
#
# The metric used in the challenge  is a *soft-threshold relative absolute error* (ST-RAE),
# and you need to implement it.
#
# * soft threshold: a prediction landing inside the molecule's credible interval costs
#   nothing. Measured pIC50s carry real error, and penalising a miss smaller than the
#   experiment's own error bar is measuring noise.
# * relative: divide by the same error for a model that predicts the mean everywhere.
#   So 1.0 means "no better than a constant" and above 1.0 means worse.
#
# Report ST-RAE, MAE, RMSE, Pearson r and Spearman rho per isoform, with the mean baseline as its own row.
# Spearman is rank-only, Pearson is linear: forests compress predictions toward the mean,
# when the two diverge that tells you about the *shape* of the error, not its size.
#
# Plot ST-RAE per isoform with the baseline at 1.0 marked, and predicted vs measured
# for one isoform with the credible intervals drawn as x error bars and the diagonal.

# %%


# %% [markdown]
# ## TASK 5 - Save the models for round 4
#
# Round 4 refuses to run if the feature layout does not match, so save the spec with
# the models. `joblib.dump(..., compress=3)` to `models/cyp.joblib`:
#
#     {
#         "models":   {target: fitted_regressor, ...},
#         "targets":  TARGETS,
#         "features": {
#             "desc_names":   [...],   # descriptor names, in column order
#             "fp_radius":    2,
#             "fp_bits":      2048,
#             "standardized": False,   # you did not standardize - say so
#         },
#     }
#
# The names matter: round 4 rebuilds the featurizer with `getattr(Descriptors, name)`,
# so they must be real RDKit descriptor names in your column order.

# %%


# %% [markdown]
# ## Discussion
#
# * Which isoform is hardest to predict, and can you think of a reason why?
# * Does your model beat the mean baseline everywhere?
# * How much did the soft threshold forgive? What happens to the ranking without it?
