# %% [markdown]
# # Round 4 - score your own designs
#
# ## Before you start
#
# Rounds 2 and 3 must have been run - this script loads what they saved:
#
#     models/cyp.joblib             four CYP regressors       (round 2)
#     models/5ht2a.joblib           classifier + regressor    (round 3)
#     models/5ht2a_reference.npz    the known ligands         (round 3)
#
# Your molecules are in `data/your_designs/workshop_designs.smi`, one per line as
# whitespace-separated SMILES and name. The docking export from day 2 sits beside them.
#

# %%
from __future__ import annotations

from pathlib import Path

import joblib
import pandas as pd

HERE = Path(__file__).resolve().parent if "__file__" in globals() else Path.cwd()
ROOT = HERE.parent if HERE.name == "scripts" else HERE

DESIGNS = ROOT / "data" / "your_designs" / "workshop_designs.smi"
DOCKING = ROOT / "data" / "your_designs" / "results_docking_phd_course_workshop_day2.csv"
MODELS = ROOT / "models"
OUT = ROOT / "results_designs"
OUT.mkdir(exist_ok=True)

NOVELTY_WARN = 0.7  # Tanimoto above this to a known ligand means you are recalling
CYP_FLAG_PIC50 = 5.0  # predicted pIC50 above this == IC50 below 10 uM


# %%
ht = joblib.load(MODELS / "5ht2a.joblib")
cyp = joblib.load(MODELS / "cyp.joblib")
spec = ht["features"]
print(f"5-HT2A models, potent cutoff pAct {ht['potent_cutoff']}")
print(f"{len(cyp['models'])} CYP models: {', '.join(cyp['targets'])}")
print(f"feature spec: {spec}")


# %%
def read_designs(path: Path) -> pd.DataFrame:
    """Whitespace-separated SMILES and an optional name. Blank lines and # ignored."""
    rows = []
    for n, line in enumerate(path.read_text().splitlines(), 1):
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split(None, 1)
        rows.append(
            {
                "line": n,
                "smiles": parts[0],
                "name": parts[1].strip() if len(parts) > 1 else f"design_{n}",
            }
        )
    return pd.DataFrame(rows)


designs = read_designs(DESIGNS)
print(f"{len(designs)} structures in {DESIGNS.name}")


# %% [markdown]
# ## TASK 1 - Featurize exactly the way the models expect
#
# The layout has to be what the models were trained on, or they are reading the wrong
# columns and will return confident nonsense.
# So do not hardcode the descriptor list:
# rebuild the featurizer from `spec["desc_names"]`, `spec["fp_radius"]`,
# `spec["fp_bits"]`, with the functions from `getattr(Descriptors, name)`. 
# Assert that the two model sets agree with each other, and that your matrix has the right width.
#
# Parse and standardize each design as in round 3.

# %%


# %% [markdown]
# ## TASK 2 - How novel is each design?
#
# Against the reference ligands in `5ht2a_reference.npz`, for each design:
#
# * Tanimoto to the nearest known ligand, and its name
# * whether the exact molecule is already in the set (InChIKey match)
#
# One subtlety worth handling: ECFP4 ignores stereochemistry, an InChIKey does not,
# so a design can score Tanimoto 1.00 and still look "new" by InChIKey.

# %%


# %% [markdown]
# ## TASK 3 - Predict the different target values for the designs
#
# Run all six models and assemble one table: the potent/weak call and its probability,
# predicted pKi, predicted pIC50 for each of the four CYP isoforms plus their max, flagged
# above `CYP_FLAG_PIC50`, and the novelty columns from task 2.
#
# Sort it the way you would actually use it, write it to `results_designs/`, and print
# a short line per design saying what is wrong with it: already known, a stereoisomer,
# too close to call novel, predicted CYP inhibitor.

# %%


# %% [markdown]
# ## TASK 4 - Plot the results
#
# Two figures:
#
# * predicted pKi against novelty (Tanimoto to the nearest known ligand), coloured by
#   the CYP flag, with the recall zone above `NOVELTY_WARN` shaded. The design names
#   carry a group number, so facet by group and grey out the other groups for scale.
#
# * the structures themselves in a grid with their scores underneath
#
# Someone should be able to see in two seconds which molecule is worth making.

# %%


# %% [markdown]
# ## TASK 5 - Comparing the model decisions with the docking simulations
#
# `DOCKING` is the Glide export from day 2, one row per pose, against two prepared
# receptor structures. Each receptor's block opens with a row for the structure itself
# that carries no score - that row is what names the block, so forward-fill it to get a
# receptor column, then drop the unscored rows and merge on the design name.
#
# Docking scores are kcal/mol, so more negative is better, while higher pKi is better.
# Invert the x axis rather than negating the scores, and give each receptor its own
# panel and its own x range: the two structures do not score on the same scale.
# Compare them only through the Spearman correlation printed on each panel.
#

# %%


# %% [markdown]
# ## Discussion
#
# * Check the novelty column first. Any of your designs is the model *recalling* rather than predicting?
# * Does any design look potent at 5-HT2A and clean across all four CYPs?
# * Where do the model and docking disagree? 
# * Can you decide which one to believe?
# * Your model says your molecule is good. What would you need to see before you believed it enough to spend money making it?
