# %% [markdown]
# # Round 1 - hit triage on LIT-PCBA / ALDH1
#
# ## The data
#
# ALDH1 is LIT-PCBA's largest target and ships under `data/AVE_unbiased/ALDH1/` as
# four whitespace-separated files with no header (`SMILES PubChem_CID`):
#
#     active_T.smi    active_V.smi      <- actives: T for training, V for validation
#     inactive_T.smi  inactive_V.smi    <- inactives: same
#
# ~5% of this library is active, so a model that calls everything inactive is 95%
# accurate and 100% useless. How to not get fooled by that?

# %%
from __future__ import annotations

from pathlib import Path

import pandas as pd

# __file__ is undefined in an interactive kernel, so fall back to the working directory.
HERE = Path(__file__).resolve().parent if "__file__" in globals() else Path.cwd()
ROOT = HERE.parent if HERE.name == "scripts" else HERE

TARGET = "ALDH1"
SEED = 0

SPLIT_DIR = ROOT / "data" / "AVE_unbiased" / TARGET
OUT = ROOT / "results_aldh1"
OUT.mkdir(exist_ok=True)


# %%
def read_smi(path: Path, label: int, split: str) -> pd.DataFrame:
    df = pd.read_csv(
        path, sep=r"\s+", header=None, names=["smiles", "cid"], dtype={"cid": str}
    )
    df["label"] = label
    df["split"] = split
    return df


raw = pd.concat(
    [
        read_smi(SPLIT_DIR / "active_T.smi", 1, "train"),
        read_smi(SPLIT_DIR / "active_V.smi", 1, "val"),
        read_smi(SPLIT_DIR / "inactive_T.smi", 0, "train"),
        read_smi(SPLIT_DIR / "inactive_V.smi", 0, "val"),
    ],
    ignore_index=True,
)
print(f"{len(raw)} molecules, {int(raw.label.sum())} actives ({100 * raw.label.mean():.2f}%)")
for (sp, lab), n in raw.groupby(["split", "label"]).size().items():
    print(f"  {sp:5s} {'active' if lab else 'inactive':8s} {n:6d}")


# %% [markdown]
# ## TASK 1 - Turn molecules into numbers
#
# A random forest cannot read a SMILES string,
# therefore, we need to use quantifiable descriptors of the molecules.
# 
# # Build two feature sets with RDKit:
#
# 1. Using interpretable physicochemical descriptors (MolWt, MolLogP, TPSA, donors,
#    acceptors, rotatable bonds, rings, FractionCSP3, qed, ...). Keep their names in
#    order. Think about what features make sense to include or not. You could even try ALL features.
# 2. ECFP4 fingerprints: `rdFingerprintGenerator.GetMorganGenerator(radius=2,
#    fpSize=2048)`, then `GetFingerprintAsNumPy`.
#
# Standardize before you featurize (`rdMolStandardize`: Cleanup -> FragmentParent ->
# Uncharger, then `Chem.SanitizeMol`), and deduplicate on `Chem.MolToInchiKey`.
# Careful, the same structure appears more than once in here,
# sometimes on both sides of the split and sometimes labelled both ways
# Decide what to do with each case and say why.
#
# ~107k molecules takes a few minutes, you can save the calculated arrays to an .npz file
# to save yourself time if you re-run your script.

# %%

# %% [markdown]
# ## TASK 2 - Inspect the split you were given
#
# You did not split the data into training and validation sets
# so check for the properties you'd like to see in the split to
# ensure they are present.
#
# Three things to check for:
#
# * Do we have duplicates? the same InChIKeys present in training and validation (this should be 0)
# * for each validation active, the highest ECFP4 Tanimoto to any *training* active -
#   plot the distribution and count how many sit above 0.6, the usual analog threshold
# * cluster the fingerprints (TruncatedSVD on a sparse matrix, then MiniBatchKMeans)
#   and count how many clusters hold molecules from both splits.

# %%


# %% [markdown]
# ## TASK 3 - Train the forest
#
# Train 3 random forests three times:
# 1. descriptors alone
# 2. fingerprints alone
# 3. both
#
# There are ~19 inactives per active, and a single forest on that mostly learns to say
# "inactive". Undersample the inactives for training only (never touch validation),
# and average a few independently undersampled forests so you do not throw away the
# inactives any one of them missed.
#
# Then fit one shallow `DecisionTreeClassifier` on the descriptors and `export_text` it. 
# Try to interpret the tree.
# 
# try to find ways to assess importance of different features in the classification.
#


# %%


# %% [markdown]
# ## TASK 4 - Measure what matters, against two baselines
#
# Accuracy is useless here and ROC-AUC is not so useful: 
# both are dominated by the inactives nobody would ever test.
# What a screen does is: 1. rank the library, 2. buy the top slice, 3. count the hits.
# That is the enrichment factor: hit rate in the top slice over the overall hit rate, so 1.0 is random.
#
# Report EF at 1%, plus AUC-PR, BEDROC and ROC-AUC. 
#
# Make two figures: EF1% as bars per feature set with both baselines drawn on, and the
# precision-recall curves with the random line.

# %%


# %% [markdown]
# ## Discussion
#
# * Which feature set won, and by how much? Was combining them worth it?
# * Did anything beat the nearest-active baseline? What does it mean if it did not?
# * How differently do EF and ROC-AUC rank the same three models?
