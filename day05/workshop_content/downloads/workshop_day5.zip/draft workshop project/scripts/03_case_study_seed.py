# %% [markdown]
# # Round 3 - 5-HT2A, the target you designed for
#
# ## The data
#
# GPCRdb serves the measured ligands of any receptor as JSON; swap the slug in the URL
# for another target. The cell below caches to `data/5ht2a_ligands.json`.
#
# Each record is a measurement: the same compound appears many times, from different papers and different assays.
# Columns worth knowing: `Smiles`, `Ligand name`, `Ligand type`, `Value type` (Ki, pKi, IC50, EC50, ...), `Assay type`
# ("B" binding, "F" functional) and `Activity value (P)`, the p-scaled value.
#
# ## What to build:
#
# 1. a classifier - potent vs weak binder
# 2. a regressor  - predicted binding affinity, pKi
#
# Both get saved for round 4, with a feature spec that matches round 2's.

# %%
from __future__ import annotations

import html
import json
from pathlib import Path

import pandas as pd
import requests

HERE = Path(__file__).resolve().parent if "__file__" in globals() else Path.cwd()
ROOT = HERE.parent if HERE.name == "scripts" else HERE

GPCRDB_URL = "https://gpcrdb.org/services/ligands/5ht2a_human/"
LIGAND_JSON = ROOT / "data" / "5ht2a_ligands.json"

MODELS = ROOT / "models"
OUT = ROOT / "results_5ht2a"
OUT.mkdir(exist_ok=True)
SEED = 0


# %%
if not LIGAND_JSON.exists():
    print(f"downloading {GPCRDB_URL}")
    r = requests.get(GPCRDB_URL, timeout=120)
    r.raise_for_status()
    LIGAND_JSON.parent.mkdir(parents=True, exist_ok=True)
    LIGAND_JSON.write_text(r.text)

records = pd.DataFrame(json.loads(LIGAND_JSON.read_text()))
print(f"{len(records)} activity records, {records.Smiles.nunique()} unique SMILES")
print(records.columns.tolist())


# %% [markdown]
# ## TASK 1 - Preprocessing
#
# Decide what variables to use:
#
# * a value type alone does not tell you what was measured. An IC50 from a *binding*
#   assay is an uncorrected affinity; an IC50 from a *functional* assay is a potency.
#   Ki is corrected for the radioligand (Cheng-Prusoff), which is what makes it
#   comparable across labs. So pin the regression target by assay type as well as value type: binding Ki only.
# * `html.unescape` the ligand names, they arrive HTML-encoded
# * collapse the many measurements per molecule into one value - median across papers,
#   not mean. Ask Claude why.
#
# You end up with two targets per molecule: a median over all usable value types for
# the coarse potent/weak cut, and the binding-Ki median for the regression. Keep them
# as separate columns.
#
# Then look at what you have: how many molecules, and where does the activity distribution bottom out.

# %%


# %% [markdown]
# ## TASK 2 - Featurise and split the data
#
# Use the same two feature sets as rounds 1 and 2, with identical descriptor list and order
# standardized as in round 1, deduplicated on InChIKey.
# Featurize the unique SMILES once and map the records back by InChIKey, not by string.
#
# Split by chemotype cluster, not at random: ligand series from one paper are near
# duplicates of each other, so a random split risks putting the same molecule on both sides.

# Assign whole clusters to either training OR validation,
# balancing both the molecule count and the number of potent molecules.
# 
# Use the same split for both models so they stay comparable,
# and evaluate with the same nearest-neighbour Tanimoto check as rounds 1 and 2 on it.

# %%


# %% [markdown]
# ## TASK 3 - The classifier: potent or weak
#
# Cut at a potency threshold and train a random forest classifier on the pooled median activity.
#
# The classes here are roughly balanced, unlike round 1, so the metrics change again:
# enrichment factor is the wrong tool now and ROC-AUC becomes meaningful.
# 
# Report balanced accuracy, Matthews correlation, ROC-AUC and average precision against the
# random values for each, and plot the ROC curve.
#
# You can try test for different potency threshold.

# %%


# %% [markdown]
# ## TASK 4 - The regressor: predicted pKi
#
# Train a random forest regressor on the binding-Ki subset only, keeping the cluster
# split from task 2 so the chemotype separation still holds on the smaller set.
#
# Report RMSE, MAE, Pearson and Spearman against a baseline that predicts the training
# mean, plus a relative absolute error against that baseline so the scale matches
# round 2.
# 
#  Note that GPCRdb reports no credible intervals, so round 2's soft threshold
# collapses to zero here - that is why the metric is RAE and not ST-RAE.
#
# Plot predicted pKi versus the measured pKi to evaluate your model.

# %%


# %% [markdown]
# ## TASK 5 - Save for round 4
#
# The feature spec must match the one you saved in round 2 - same descriptor names in
# the same order, same radius, same bit count - or round 4 fails its assertions.
#
# `joblib.dump(..., compress=3)` to `models/5ht2a.joblib`:
#
#     {
#         "classifier":     fitted_classifier,
#         "regressor":      fitted_regressor,
#         "potent_cutoff":  7.0,
#         "features": {"desc_names": [...], "fp_radius": 2, "fp_bits": 2048,
#                      "standardized": True},
#     }
#
# And the known ligands themselves to `models/5ht2a_reference.npz`, so round 4 can
# ask how novel a submitted structure is:
#
#     fp         fingerprint matrix of the known ligands
#     name       ligand names
#     inchikey   InChIKeys
#     pact_all   pooled median activity
#     pKi        the regression target
#
# %%


# %% [markdown]
# ## Discussion
#
# * Where did you put the potent/weak threshold, and what happened when you moved it?
# * You have a model that scores 5-HT2A ligands. What would it do with a molecule that
#   binds nothing at all, and would you be able to tell?
