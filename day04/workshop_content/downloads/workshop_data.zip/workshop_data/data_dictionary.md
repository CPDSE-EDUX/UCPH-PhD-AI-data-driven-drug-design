# Workshop dataset: a 26-week type 2 diabetes trial (simulated)

1,200 adults with type 2 diabetes were randomised to 3 arms,
**Placebo**, **5 mg** or **10 mg**, of an investigational oral drug (400 per arm) and followed for 26 weeks.
Goal of the drug: lower blood sugar (HbA1c) without causing too many side effects.

## Quick primer
- **HbA1c (%)**: long-term blood sugar. **Lower is better.** A change of -1.0 means HbA1c dropped by one percentage point.
- A **negative change** in HbA1c or weight means improvement / loss.
- **Adverse event (AE)**: any unwanted medical event reported during the trial.
- **Background therapy**: what the patient was already taking. *SU* = sulfonylurea.

## participants.csv (one row per patient, 1,200 rows)
| Column | Meaning |
|---|---|
| patient_id | Unique ID (P0001 ...) |
| arm | Placebo, 5 mg or 10 mg |
| dose_mg | 0, 5 or 10 |
| site, country | Trial site code and country (12 sites, 5 countries) |
| sex | F or M |
| age | Years |
| bmi | Body mass index at baseline (kg/m²) |
| baseline_weight_kg | Body weight at baseline |
| background_therapy | Metformin, Metformin + SU, or Insulin |
| disease_duration_yrs | Years since diabetes diagnosis |
| baseline_hba1c | HbA1c (%) at week 0 |
| c_peptide_nmol_l | Blood marker of the body's own insulin production (higher = more) |
| completed | yes if the patient finished all 26 weeks |
| discontinuation_week | Week the patient left the study (empty if completed) |
| discontinuation_reason | Why they left (empty if completed) |
| hba1c_change_w26 | HbA1c at week 26 minus baseline (%-points). **Empty if the patient did not reach week 26.** |
| weight_change_w26_kg | Weight at week 26 minus baseline (kg). **Empty if the patient did not reach week 26.** |

## visits.csv (one row per patient and visit)
| Column | Meaning |
|---|---|
| patient_id, arm | As above |
| week | Visit week: 0, 4, 8, 12, 16, 20, 26 |
| hba1c | HbA1c (%) at that visit |
| weight_kg | Body weight (kg) at that visit |

Patients who left the study have no rows after they left, so this table is not complete for everyone.

## adverse_events.csv (one row per event, 951 rows)
| Column | Meaning |
|---|---|
| patient_id, arm | As above |
| ae_term | Name of the event (e.g. Nausea) |
| ae_category | Body-system group of the event |
| onset_week | Week the event started |
| severity | Mild, Moderate or Severe |

A patient can have several events, and patients with no events do not appear in this table.
To get percentages you need the number of patients per arm from participants.csv (400 each).
